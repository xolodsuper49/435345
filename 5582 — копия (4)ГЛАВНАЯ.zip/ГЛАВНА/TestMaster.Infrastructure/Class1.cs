﻿namespace TestMaster.Infrastructure;

public class Class1
{

}
