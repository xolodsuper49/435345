﻿namespace TestMaster.Application;

public class Class1
{

}
