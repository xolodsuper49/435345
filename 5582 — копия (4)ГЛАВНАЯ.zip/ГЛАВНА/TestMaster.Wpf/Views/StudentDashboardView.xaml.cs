using System.Windows.Controls;
using TestMaster.Wpf.Helpers;
namespace TestMaster.Wpf.Views;

public partial class StudentDashboardView : UserControl
{
    public StudentDashboardView()
    {
        InitializeComponent();
    }
}