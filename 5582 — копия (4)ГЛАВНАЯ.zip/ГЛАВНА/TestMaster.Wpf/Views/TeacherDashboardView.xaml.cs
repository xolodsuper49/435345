﻿using System.Windows.Controls;
namespace TestMaster.Wpf.Views;
public partial class TeacherDashboardView : UserControl
{
    public TeacherDashboardView()
    {
        InitializeComponent();
    }
}
