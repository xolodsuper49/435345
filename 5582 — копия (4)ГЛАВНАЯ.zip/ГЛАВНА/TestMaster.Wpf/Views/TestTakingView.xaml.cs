using System.Windows.Controls;
namespace TestMaster.Wpf.Views;
public partial class TestTakingView : UserControl
{
    public TestTakingView() { InitializeComponent(); }
}