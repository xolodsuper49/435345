﻿namespace TestMaster.Domain;

public class Class1
{

}
