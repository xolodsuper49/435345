﻿namespace TestMaster.Domain.Enums;
public enum Role { Administrator, Teacher, Student }
