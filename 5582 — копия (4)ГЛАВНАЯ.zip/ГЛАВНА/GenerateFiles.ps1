# PowerShell Script to generate all project files for TestMaster

$basePath = Get-Location

# Helper function to create a file with content
function New-FileWithContent {
    param(
        [string]$Path,
        [string]$Content
    )
    $dir = Split-Path -Parent $Path
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir | Out-Null
    }
    Set-Content -Path $Path -Value $Content -Encoding UTF8
}

Write-Host "Generating files for TestMaster.Domain..."

$domainEntitiesPath = Join-Path $basePath "TestMaster.Domain\Entities"
$domainEnumsPath = Join-Path $basePath "TestMaster.Domain\Enums"

# Domain Files
$baseEntityContent = @"
using System;
public abstract class BaseEntity
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
"@
New-FileWithContent -Path (Join-Path $domainEntitiesPath "BaseEntity.cs") -Content $baseEntityContent

$roleEnumContent = @"
namespace TestMaster.Domain.Enums;
public enum Role { Administrator, Teacher, Student }
"@
New-FileWithContent -Path (Join-Path $domainEnumsPath "Role.cs") -Content $roleEnumContent

$userEntityContent = @"
using TestMaster.Domain.Enums;
public class User : BaseEntity
{
    public string UserName { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public Role Role { get; set; }
}
"@
New-FileWithContent -Path (Join-Path $domainEntitiesPath "User.cs") -Content $userEntityContent

$questionEntityContent = @"
using System.Collections.Generic;
public class Question : BaseEntity
{
    public string Text { get; set; } = string.Empty;
    public ICollection<AnswerOption> Options { get; set; } = new List<AnswerOption>();
}
"@
New-FileWithContent -Path (Join-Path $domainEntitiesPath "Question.cs") -Content $questionEntityContent

$answerOptionEntityContent = @"
using System;
public class AnswerOption : BaseEntity
{
    public string Text { get; set; } = string.Empty;
    public bool IsCorrect { get; set; }
    public Guid QuestionId { get; set; }
    public Question Question { get; set; } = null!;
}
"@
New-FileWithContent -Path (Join-Path $domainEntitiesPath "AnswerOption.cs") -Content $answerOptionEntityContent

Write-Host "Generating files for TestMaster.Application..."

$appInterfacesPath = Join-Path $basePath "TestMaster.Application\Interfaces"
$appServicesPath = Join-Path $basePath "TestMaster.Application\Services"

# Application Files
$iAuthServiceContent = @"
public interface IAuthService
{
    User? CurrentUser { get; }
    System.Threading.Tasks.Task<(bool, string)> LoginAsync(string username, string password);
    void Logout();
}
"@
New-FileWithContent -Path (Join-Path $appInterfacesPath "IAuthService.cs") -Content $iAuthServiceContent

$iQuestionServiceContent = @"
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
public interface IQuestionService
{
    Task<List<Question>> GetAllQuestionsAsync();
    Task CreateQuestionAsync(string text, List<(string Text, bool IsCorrect)> options);
    Task UpdateQuestionAsync(Guid questionId, string text, List<(string Text, bool IsCorrect)> options);
    Task DeleteQuestionAsync(Guid questionId);
}
"@
New-FileWithContent -Path (Join-Path $appInterfacesPath "IQuestionService.cs") -Content $iQuestionServiceContent

$passwordHelperContent = @"
using System;
using System.Security.Cryptography;
public static class PasswordHelper
{
    public static string HashPassword(string password)
    {
        byte[] salt = new byte[16];
        RandomNumberGenerator.Fill(salt);
        var hash = Rfc2898DeriveBytes.Pbkdf2(password, salt, 10000, HashAlgorithmName.SHA256, 32);
        return $"`{Convert.ToBase64String(salt)}:`{Convert.ToBase64String(hash)}";
    }
    public static bool VerifyPassword(string password, string storedHash)
    {
        var parts = storedHash.Split(':', 2);
        if (parts.Length != 2) return false;
        var salt = Convert.FromBase64String(parts[0]);
        var hash = Convert.FromBase64String(parts[1]);
        var computed = Rfc2898DeriveBytes.Pbkdf2(password, salt, 10000, HashAlgorithmName.SHA256, 32);
        return CryptographicOperations.FixedTimeEquals(hash, computed);
    }
}
"@
New-FileWithContent -Path (Join-Path $appServicesPath "PasswordHelper.cs") -Content $passwordHelperContent

$authServiceContent = @"
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
public class AuthService : IAuthService
{
    private readonly AppDbContext _db;
    public User? CurrentUser { get; private set; }

    public AuthService(AppDbContext db) => _db = db;

    public async Task<(bool, string)> LoginAsync(string username, string password)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.UserName == username);
        if (user == null) return (false, "����������� �� ��������.");
        if (!PasswordHelper.VerifyPassword(password, user.PasswordHash)) return (false, "������� ������.");
        
        CurrentUser = user;
        return (true, "���� �������.");
    }
    public void Logout() => CurrentUser = null;
}
"@
New-FileWithContent -Path (Join-Path $appServicesPath "AuthService.cs") -Content $authServiceContent

$questionServiceContent = @"
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
public class QuestionService : IQuestionService
{
    private readonly AppDbContext _db;
    public QuestionService(AppDbContext db) => _db = db;

    public Task<List<Question>> GetAllQuestionsAsync() => _db.Questions.Include(q => q.Options).ToListAsync();

    public async Task CreateQuestionAsync(string text, List<(string Text, bool IsCorrect)> options)
    {
        var question = new Question { Text = text };
        _db.Questions.Add(question);

        foreach (var opt in options)
        {
            _db.AnswerOptions.Add(new AnswerOption { Question = question, Text = opt.Text, IsCorrect = opt.IsCorrect });
        }
        await _db.SaveChangesAsync();
    }
    
    public async Task UpdateQuestionAsync(Guid questionId, string text, List<(string Text, bool IsCorrect)> options)
    {
        var question = await _db.Questions.Include(q => q.Options).FirstAsync(q => q.Id == questionId);
        question.Text = text;
        _db.AnswerOptions.RemoveRange(question.Options);
        
        foreach (var opt in options)
        {
            _db.AnswerOptions.Add(new AnswerOption { QuestionId = questionId, Text = opt.Text, IsCorrect = opt.IsCorrect });
        }
        await _db.SaveChangesAsync();
    }

    public async Task DeleteQuestionAsync(Guid questionId)
    {
        var question = await _db.Questions.FindAsync(questionId);
        if(question != null)
        {
            _db.Questions.Remove(question);
            await _db.SaveChangesAsync();
        }
    }
}
"@
New-FileWithContent -Path (Join-Path $appServicesPath "QuestionService.cs") -Content $questionServiceContent


Write-Host "Generating files for TestMaster.Infrastructure..."
$infraDataPath = Join-Path $basePath "TestMaster.Infrastructure\Data"

$appDbContextContent = @"
using Microsoft.EntityFrameworkCore;
public class AppDbContext : DbContext
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Question> Questions => Set<Question>();
    public DbSet<AnswerOption> AnswerOptions => Set<AnswerOption>();

    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public static async System.Threading.Tasks.Task InitializeDatabaseAsync(AppDbContext context)
    {
        await context.Database.EnsureCreatedAsync();
        if (await context.Users.AnyAsync()) return;

        var users = new[]
        {
            new User { UserName = "teacher", Role = TestMaster.Domain.Enums.Role.Teacher, PasswordHash = PasswordHelper.HashPassword("teacher") },
            new User { UserName = "student", Role = TestMaster.Domain.Enums.Role.Student, PasswordHash = PasswordHelper.HashPassword("student") }
        };
        await context.Users.AddRangeAsync(users);
        await context.SaveChangesAsync();
    }
}
"@
New-FileWithContent -Path (Join-Path $infraDataPath "AppDbContext.cs") -Content $appDbContextContent


Write-Host "Generating files for TestMaster.Wpf..."

# Clean up default WPF files
Remove-Item (Join-Path $basePath "TestMaster.Wpf\MainWindow.xaml") -ErrorAction SilentlyContinue
Remove-Item (Join-Path $basePath "TestMaster.Wpf\MainWindow.xaml.cs") -ErrorAction SilentlyContinue

$wpfViewModelsPath = Join-Path $basePath "TestMaster.Wpf\ViewModels"
$wpfViewsPath = Join-Path $basePath "TestMaster.Wpf\Views"
$wpfHelpersPath = Join-Path $basePath "TestMaster.Wpf\Helpers"

# Wpf Files
$appXamlContent = @"
<Application x:Class="TestMaster.Wpf.App"
             xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
             xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
             xmlns:vm="clr-namespace:TestMaster.Wpf.ViewModels"
             xmlns:v="clr-namespace:TestMaster.Wpf.Views">
    <Application.Resources>
        <DataTemplate DataType=`"{x:Type vm:LoginViewModel}`">
            <v:LoginView/>
        </DataTemplate>
        <DataTemplate DataType=`"{x:Type vm:TeacherDashboardViewModel}`">
            <v:TeacherDashboardView/>
        </DataTemplate>
        <!-- Add other templates here as needed -->
    </Application.Resources>
</Application>
"@
New-FileWithContent -Path (Join-Path $basePath "TestMaster.Wpf\App.xaml") -Content $appXamlContent

$appXamlCsContent = @"
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using System.Windows;
using Microsoft.EntityFrameworkCore;
using System.IO;
using System;
using TestMaster.Wpf.ViewModels;
using TestMaster.Wpf.Views;

namespace TestMaster.Wpf;

public partial class App : Application
{
    private readonly IHost _host;
    public App()
    {
        _host = Host.CreateDefaultBuilder()
            .ConfigureServices(services =>
            {
                var dbPath = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TestMaster.db");
                services.AddDbContext<AppDbContext>(opt => opt.UseSqlite($`"Data Source=`{dbPath}`"), ServiceLifetime.Singleton);

                // Register all services and viewmodels as Singleton for simplicity
                services.AddSingleton<IAuthService, AuthService>();
                services.AddSingleton<IQuestionService, QuestionService>();

                services.AddSingleton<ShellViewModel>();
                services.AddSingleton<TeacherDashboardViewModel>();
                
                // Transient for dialogs and login
                services.AddTransient<LoginViewModel>();
                services.AddTransient<QuestionEditorViewModel>();
                
                // Windows
                services.AddSingleton<MainWindow>();
                services.AddTransient<QuestionEditorView>();
            })
            .Build();
    }

    protected override async void OnStartup(StartupEventArgs e)
    {
        await _host.StartAsync();
        
        var dbContext = _host.Services.GetRequiredService<AppDbContext>();
        await AppDbContext.InitializeDatabaseAsync(dbContext);

        var mainWindow = _host.Services.GetRequiredService<MainWindow>();
        mainWindow.Show();
        base.OnStartup(e);
    }
}
"@
New-FileWithContent -Path (Join-Path $basePath "TestMaster.Wpf\App.xaml.cs") -Content $appXamlCsContent


$mainWindowXamlContent = @"
<Window x:Class="TestMaster.Wpf.Views.MainWindow"
        xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="�����������" Height="720" Width="1200"
        WindowStartupLocation="CenterScreen">
    <ContentControl Content=`"{Binding CurrentViewModel}`"/>
</Window>
"@
New-FileWithContent -Path (Join-Path $wpfViewsPath "MainWindow.xaml") -Content $mainWindowXamlContent

$mainWindowXamlCsContent = @"
using System.Windows;
using TestMaster.Wpf.ViewModels;
namespace TestMaster.Wpf.Views;
public partial class MainWindow : Window
{
    public MainWindow(ShellViewModel vm)
    {
        InitializeComponent();
        DataContext = vm;
    }
}
"@
New-FileWithContent -Path (Join-Path $wpfViewsPath "MainWindow.xaml.cs") -Content $mainWindowXamlCsContent

# Helper ViewModels
$viewModelBaseContent = @"
using System.ComponentModel;
using System.Runtime.CompilerServices;
public abstract class ViewModelBase : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;
    protected void OnPropertyChanged([CallerMemberName] string? name = null) 
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
"@
New-FileWithContent -Path (Join-Path $wpfHelpersPath "ViewModelBase.cs") -Content $viewModelBaseContent

$relayCommandContent = @"
using System;
using System.Windows.Input;
public class RelayCommand : ICommand
{
    private readonly Action<object?> _execute;
    private readonly Predicate<object?>? _canExecute;
    public event EventHandler? CanExecuteChanged
    {
        add => CommandManager.RequerySuggested += value;
        remove => CommandManager.RequerySuggested -= value;
    }
    public RelayCommand(Action<object?> execute, Predicate<object?>? canExecute = null)
    {
        _execute = execute;
        _canExecute = canExecute;
    }
    public bool CanExecute(object? parameter) => _canExecute?.Invoke(parameter) ?? true;
    public void Execute(object? parameter) => _execute(parameter);
}
"@
New-FileWithContent -Path (Join-Path $wpfHelpersPath "RelayCommand.cs") -Content $relayCommandContent

# Main ViewModels and Views will be added in the next message
# This script sets up the core structure.

Write-Host "Core files generated successfully!"
Write-Host "Next, copy the remaining ViewModel and View files."