# PowerShell Script to generate UI files for TestMaster

$basePath = Get-Location

# Helper function to create a file with content
function New-FileWithContent {
    param(
        [string]$Path,
        [string]$Content
    )
    $dir = Split-Path -Parent $Path
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir | Out-Null
    }
    Set-Content -Path $Path -Value $Content -Encoding UTF8
}

Write-Host "Generating UI ViewModel and View files..."

$wpfViewModelsPath = Join-Path $basePath "TestMaster.Wpf\ViewModels"
$wpfViewsPath = Join-Path $basePath "TestMaster.Wpf\Views"

# --- ViewModels ---

$shellViewModelContent = @"
using TestMaster.Domain.Enums;
namespace TestMaster.Wpf.ViewModels;

public class ShellViewModel : ViewModelBase
{
    private readonly System.IServiceProvider _serviceProvider;
    private readonly IAuthService _authService;
    private object? _currentViewModel;

    public object? CurrentViewModel
    {
        get => _currentViewModel;
        set { _currentViewModel = value; OnPropertyChanged(); }
    }

    public ShellViewModel(System.IServiceProvider serviceProvider, IAuthService authService)
    {
        _serviceProvider = serviceProvider;
        _authService = authService;
        ShowLoginView();
    }

    private void ShowLoginView()
    {
        var loginVm = _serviceProvider.GetService<LoginViewModel>()!;
        loginVm.LoginSuccess += OnLoginSuccess;
        CurrentViewModel = loginVm;
    }

    private void OnLoginSuccess()
    {
        // Unsubscribe to avoid memory leaks
        if (CurrentViewModel is LoginViewModel loginVm)
        {
            loginVm.LoginSuccess -= OnLoginSuccess;
        }

        if (_authService.CurrentUser?.Role == Role.Teacher)
        {
            var teacherVm = _serviceProvider.GetService<TeacherDashboardViewModel>()!;
            teacherVm.LogoutRequested += ShowLoginView;
            CurrentViewModel = teacherVm;
        }
        // TODO: Add logic for Student role
    }
}
"@
New-FileWithContent -Path (Join-Path $wpfViewModelsPath "ShellViewModel.cs") -Content $shellViewModelContent

$loginViewModelContent = @"
using System;
using System.Threading.Tasks;
using System.Windows.Input;
namespace TestMaster.Wpf.ViewModels;

public class LoginViewModel : ViewModelBase
{
    private readonly IAuthService _authService;
    private string _username = "";
    private string _password = "";
    private string _error = "";
    
    public event Action? LoginSuccess;

    public string Username { get => _username; set { _username = value; OnPropertyChanged(); } }
    public string Password { get => _password; set { _password = value; OnPropertyChanged(); } }
    public string Error { get => _error; set { _error = value; OnPropertyChanged(); } }

    public ICommand LoginCommand { get; }

    public LoginViewModel(IAuthService authService)
    {
        _authService = authService;
        LoginCommand = new RelayCommand(async _ => await ExecuteLogin(), _ => !string.IsNullOrWhiteSpace(Username));
    }

    private async Task ExecuteLogin()
    {
        Error = "";
        var (success, message) = await _authService.LoginAsync(Username, Password);
        if (success)
        {
            LoginSuccess?.Invoke();
        }
        else
        {
            Error = message;
        }
    }
}
"@
New-FileWithContent -Path (Join-Path $wpfViewModelsPath "LoginViewModel.cs") -Content $loginViewModelContent

$teacherDashboardViewModelContent = @"
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using TestMaster.Wpf.Views;
namespace TestMaster.Wpf.ViewModels;

public class TeacherDashboardViewModel : ViewModelBase
{
    private readonly IQuestionService _questionService;
    private readonly System.IServiceProvider _serviceProvider;
    
    public event Action? LogoutRequested;

    public ObservableCollection<Question> Questions { get; } = new();
    
    private Question? _selectedQuestion;
    public Question? SelectedQuestion { get => _selectedQuestion; set { _selectedQuestion = value; OnPropertyChanged(); } }

    public ICommand AddQuestionCommand { get; }
    public ICommand EditQuestionCommand { get; }
    public ICommand DeleteQuestionCommand { get; }
    public ICommand LogoutCommand { get; }

    public TeacherDashboardViewModel(IQuestionService questionService, System.IServiceProvider serviceProvider)
    {
        _questionService = questionService;
        _serviceProvider = serviceProvider;

        AddQuestionCommand = new RelayCommand(async _ => await AddQuestion());
        EditQuestionCommand = new RelayCommand(async _ => await EditQuestion(), _ => SelectedQuestion != null);
        DeleteQuestionCommand = new RelayCommand(async _ => await DeleteQuestion(), _ => SelectedQuestion != null);
        LogoutCommand = new RelayCommand(_ => LogoutRequested?.Invoke());

        _ = LoadQuestions();
    }

    private async Task LoadQuestions()
    {
        Questions.Clear();
        var questions = await _questionService.GetAllQuestionsAsync();
        foreach (var q in questions)
        {
            Questions.Add(q);
        }
    }

    private async Task AddQuestion()
    {
        var editorVm = _serviceProvider.GetService<QuestionEditorViewModel>()!;
        var editorView = new QuestionEditorView(editorVm);
        
        if (editorView.ShowDialog() == true)
        {
            await _questionService.CreateQuestionAsync(editorVm.QuestionText, editorVm.AnswerOptions.Select(o => (o.Text, o.IsCorrect)).ToList());
            await LoadQuestions();
        }
    }

    private async Task EditQuestion()
    {
        if (SelectedQuestion == null) return;
        
        var editorVm = _serviceProvider.GetService<QuestionEditorViewModel>()!;
        editorVm.LoadQuestion(SelectedQuestion);
        var editorView = new QuestionEditorView(editorVm);

        if (editorView.ShowDialog() == true)
        {
            await _questionService.UpdateQuestionAsync(SelectedQuestion.Id, editorVm.QuestionText, editorVm.AnswerOptions.Select(o => (o.Text, o.IsCorrect)).ToList());
            await LoadQuestions();
        }
    }

    private async Task DeleteQuestion()
    {
        if (SelectedQuestion == null) return;
        // NOTE: For simplicity, this is a hard delete.
        await _questionService.DeleteQuestionAsync(SelectedQuestion.Id);
        await LoadQuestions();
    }
}
"@
New-FileWithContent -Path (Join-Path $wpfViewModelsPath "TeacherDashboardViewModel.cs") -Content $teacherDashboardViewModelContent

$questionEditorViewModelContent = @"
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
namespace TestMaster.Wpf.ViewModels;

public class AnswerOptionViewModel : ViewModelBase
{
    private string _text = "";
    public string Text { get => _text; set => Set(ref _text, value); }
    private bool _isCorrect;
    public bool IsCorrect { get => _isCorrect; set => Set(ref _isCorrect, value); }
}

public class QuestionEditorViewModel : ViewModelBase
{
    public event EventHandler<bool>? RequestClose;

    private string _questionText = "���� ���������";
    public string QuestionText { get => _questionText; set => Set(ref _questionText, value); }
    
    public ObservableCollection<AnswerOptionViewModel> AnswerOptions { get; } = new();

    public ICommand SaveCommand { get; }
    public ICommand CancelCommand { get; }
    public ICommand AddOptionCommand { get; }
    public ICommand RemoveOptionCommand { get; }

    public QuestionEditorViewModel()
    {
        SaveCommand = new RelayCommand(_ => RequestClose?.Invoke(this, true), _ => AnswerOptions.Any(o => o.IsCorrect));
        CancelCommand = new RelayCommand(_ => RequestClose?.Invoke(this, false));
        AddOptionCommand = new RelayCommand(_ => AnswerOptions.Add(new AnswerOptionViewModel { Text = "����� ������" }));
        RemoveOptionCommand = new RelayCommand(param => { if (param is AnswerOptionViewModel o) AnswerOptions.Remove(o); });

        AnswerOptions.Add(new AnswerOptionViewModel { Text = "������ �", IsCorrect = true });
        AnswerOptions.Add(new AnswerOptionViewModel { Text = "������ �" });
    }
    
    public void LoadQuestion(Question question)
    {
        QuestionText = question.Text;
        AnswerOptions.Clear();
        foreach (var option in question.Options)
        {
            AnswerOptions.Add(new AnswerOptionViewModel { Text = option.Text, IsCorrect = option.IsCorrect });
        }
    }
}
"@
New-FileWithContent -Path (Join-Path $wpfViewModelsPath "QuestionEditorViewModel.cs") -Content $questionEditorViewModelContent

# --- Views ---

$loginViewXamlContent = @"
<UserControl x:Class="TestMaster.Wpf.Views.LoginView"
             xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
             xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml">
    <Grid>
        <StackPanel HorizontalAlignment="Center" VerticalAlignment="Center" Width="300">
            <TextBlock Text="���� �� �������" FontSize="20" Margin="5"/>
            <TextBlock Text="����:"/>
            <TextBox Text=`"{Binding Username, UpdateSourceTrigger=PropertyChanged}`" Margin="5"/>
            <TextBlock Text="������:"/>
            <PasswordBox Name="PasswordBox" Margin="5"/>
            <Button Content="�����" Command=`"{Binding LoginCommand}`" CommandParameter=`"{Binding ElementName=PasswordBox}`" Margin="5"/>
            <TextBlock Text=`"{Binding Error}`" Foreground="Red" Margin="5"/>
        </StackPanel>
    </Grid>
</UserControl>
"@
New-FileWithContent -Path (Join-Path $wpfViewsPath "LoginView.xaml") -Content $loginViewXamlContent

$loginViewXamlCsContent = @"
using System.Windows;
using System.Windows.Controls;
using TestMaster.Wpf.ViewModels;

namespace TestMaster.Wpf.Views;
public partial class LoginView : UserControl
{
    public LoginView()
    {
        InitializeComponent();
        // This is a common pattern to handle PasswordBox, which is not dependency property
        PasswordBox.PasswordChanged += OnPasswordChanged;
    }

    private void OnPasswordChanged(object sender, RoutedEventArgs e)
    {
        if (DataContext is LoginViewModel vm)
        {
            vm.Password = ((PasswordBox)sender).Password;
        }
    }
}
"@
New-FileWithContent -Path (Join-Path $wpfViewsPath "LoginView.xaml.cs") -Content $loginViewXamlCsContent

$teacherDashboardViewXamlContent = @"
<UserControl x:Class="TestMaster.Wpf.Views.TeacherDashboardView"
             xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
             xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml">
    <DockPanel Margin="10">
        <StackPanel DockPanel.Dock="Top" Orientation="Horizontal">
            <Button Content="������ ���������" Command=`"{Binding AddQuestionCommand}`" Margin="5"/>
            <Button Content="����������" Command=`"{Binding EditQuestionCommand}`" Margin="5"/>
            <Button Content="��������" Command=`"{Binding DeleteQuestionCommand}`" Margin="5"/>
            <Button Content="�����" Command=`"{Binding LogoutCommand}`" Margin="5" HorizontalAlignment="Right"/>
        </StackPanel>
        
        <ListView ItemsSource=`"{Binding Questions}`" SelectedItem=`"{Binding SelectedQuestion}`" Margin="5">
            <ListView.View>
                <GridView>
                    <GridViewColumn Header="����� ���������" DisplayMemberBinding=`"{Binding Text}`" Width="500"/>
                </GridView>
            </ListView.View>
        </ListView>
    </DockPanel>
</UserControl>
"@
New-FileWithContent -Path (Join-Path $wpfViewsPath "TeacherDashboardView.xaml") -Content $teacherDashboardViewXamlContent

$teacherDashboardViewXamlCsContent = @"
using System.Windows.Controls;
namespace TestMaster.Wpf.Views;
public partial class TeacherDashboardView : UserControl
{
    public TeacherDashboardView()
    {
        InitializeComponent();
    }
}
"@
New-FileWithContent -Path (Join-Path $wpfViewsPath "TeacherDashboardView.xaml.cs") -Content $teacherDashboardViewXamlCsContent

$questionEditorViewXamlContent = @"
<Window x:Class="TestMaster.Wpf.Views.QuestionEditorView"
        xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="�������� ���������" Height="450" Width="600"
        WindowStartupLocation="CenterOwner" ResizeMode="NoResize">
    <DockPanel Margin="10">
        <StackPanel DockPanel.Dock="Bottom" Orientation="Horizontal" HorizontalAlignment="Right">
            <Button Content="��������" IsDefault="True" Command=`"{Binding SaveCommand}`" Width="100" Margin="5"/>
            <Button Content="���������" IsCancel="True" Command=`"{Binding CancelCommand}`" Width="100" Margin="5"/>
        </StackPanel>
        
        <StackPanel>
            <TextBlock Text="����� ���������:"/>
            <TextBox Text=`"{Binding QuestionText, UpdateSourceTrigger=PropertyChanged}`" AcceptsReturn="True" Height="100" TextWrapping="Wrap" Margin="5"/>

            <TextBlock Text="������� ������ (�������� ����������):" Margin="5"/>
            <ItemsControl ItemsSource=`"{Binding AnswerOptions}`">
                <ItemsControl.ItemTemplate>
                    <DataTemplate>
                        <Grid Margin="2">
                            <Grid.ColumnDefinitions>
                                <ColumnDefinition Width="Auto"/>
                                <ColumnDefinition Width="*"/>
                                <ColumnDefinition Width="Auto"/>
                            </Grid.ColumnDefinitions>
                            <RadioButton Grid.Column="0" IsChecked=`"{Binding IsCorrect}`" GroupName="CorrectAnswerGroup"/>
                            <TextBox Grid.Column="1" Text=`"{Binding Text, UpdateSourceTrigger=PropertyChanged}`" Margin="5,0"/>
                            <Button Grid.Column="2" Content="X" Foreground="Crimson" Command=`"{Binding DataContext.RemoveOptionCommand, RelativeSource=`{RelativeSource AncestorType=ItemsControl}}`" CommandParameter=`"{Binding}`"/>
                        </Grid>
                    </DataTemplate>
                </ItemsControl.ItemTemplate>
            </ItemsControl>
            <Button Content="������ ������" Command=`"{Binding AddOptionCommand}`" HorizontalAlignment="Left" Margin="5"/>
        </StackPanel>
    </DockPanel>
</Window>
"@
New-FileWithContent -Path (Join-Path $wpfViewsPath "QuestionEditorView.xaml") -Content $questionEditorViewXamlContent

$questionEditorViewXamlCsContent = @"
using System.Windows;
using TestMaster.Wpf.ViewModels;

namespace TestMaster.Wpf.Views;

public partial class QuestionEditorView : Window
{
    public QuestionEditorView(QuestionEditorViewModel vm)
    {
        InitializeComponent();
        DataContext = vm;
        
        vm.RequestClose += (sender, result) =>
        {
            DialogResult = result;
            Close();
        };
    }
}
"@
New-FileWithContent -Path (Join-Path $wpfViewsPath "QuestionEditorView.xaml.cs") -Content $questionEditorViewXamlCsContent

Write-Host "UI files generated successfully!"
Write-Host "Now you can run the project: dotnet run --project TestMaster.Wpf"